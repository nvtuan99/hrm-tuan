﻿jQuery(document).ready(function () {
    jQuery('#DateBuy').datetimepicker({
        timepicker: false,
        format: 'Y/m/d',
    });
    jQuery('#DateWarranty').datetimepicker({
        timepicker: false,
        format: 'Y/m/d',
    });
});