﻿$(document).ready(function () {
    $('#dtSalarySheetDetail').DataTable({
        "order": [[0, "desc"]],
    });
});