﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HRManager.Controllers
{
    public class TimekeepingHistoryController : Controller
    {
        // GET: TimekeepingHistory
        public ActionResult Index()
        {
            return View();
        }
    }
}