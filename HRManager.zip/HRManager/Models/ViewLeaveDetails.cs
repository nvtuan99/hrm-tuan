﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRManager.Models
{
    public class ViewLeaveDetails
    {
        public decimal totalDayLeave { get; set; }
        public decimal totalHoursLeave { get; set; }
    }
}